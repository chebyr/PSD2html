package psd.parser.layer.additional;

import psd.parser.object.PsdDescriptor;

public interface LayerMetaDataHandler {

	public void metaDataMlstSectionParsed(PsdDescriptor descriptor);
}
