package psd.parser.layer.additional;

public interface LayerIdHandler {
	public void layerIdParsed(int id);
}
