package psd.parser.layer.additional;

public interface LayerUnicodeNameHandler {
	public void layerUnicodeNameParsed(String unicodeName);
}
