package psd.parser.imageresource;

import psd.parser.object.PsdDescriptor;


public interface ImageResourceSectionHandler {
	public void imageResourceManiSectionParsed(PsdDescriptor descriptor);
}
